project.py is the script which contains all the work that I have done. They are divided into 11 cells in this script.

 	Cell 1: This cell simply loads all the packages that I have used.

	Cell 2: How I implement average precision and average NDCG metrics.
        	The two function will require a txt file produced by a retrieval model on the validation dataset in order to proceed.

	Cell 3: Use this two metrics functions to evaluate the performance of the BM25 model.

	Cell 4: Data preprocessing stage. I use a pre-trained word embedding model, which can be downloaded at https://dl.fbaipublicfiles.com/fasttext/vectors-crawl/cc.en.300.bin.gz .
	
	Cell 5: Load the data, these data will be used in the rest of the script.  

	Cell 6: Implment logistic regression

	Cell 7: Explore the effect of different learning rates on the training cost

	Cell 8: Evaluate the logistic regression, produce the output file.

	Cell 9: Tune the xgboost. You can modify the values in the list to find the best parameters.

	Cell 10: Train the xgboost model with lambdamart algorithm, validate performance, produce the output file.

	Cell 11: BUild the neural network, validate performance, produce the output file.


cw2.pdf is the report.

NN.txt, LM.txt, LR.txt are the requested output files.

NN_val.txt, LM_val.txt, LR_val.txt are the retrieved passages from the validation data. They are used to evaluate the three models' performance.

BM25.txt is also the retrieved passages from the validation data, and it was used to evaluate the performance of the BM25 previously implemented.