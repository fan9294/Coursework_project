# -*- coding: utf-8 -*-
"""
Created on Sat Apr 11 15:23:46 2020

@author: fanta
"""
#%% 1.Packages
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from gensim.models.wrappers import FastText
from time import time
from xgboost import XGBRanker
import xgboost
import tensorflow as tf
import keras
from keras.models import Sequential
from keras.layers import Dense
np.random.seed(2020)

#%% 2.Metrics implementation


def precision_calculator(output_name, data_val_name):
    # This function takes the txt file produced by a retrieval model and the validation dataset,
    # and return the average precision of this model.
   
    # Read in both file as seperate dataframe 
    output = pd.read_csv(output_name, header = None, sep = '  ',
                         names = ['qid', 'assignment', 'pid', 'rank', 'score', 'model'])
    data_val = pd.read_csv(data_val_name, sep='\t')
    
    # Join them toghether so we can see the true relevancy score of the retrieved passages.
    data = pd.merge(left = output, right = data_val[['pid','qid','relevancy']], on = ['qid','pid'])
    # Create a empty list.
    precision = []
    # An array that has all the qids in it.
    q_ids = data['qid'].value_counts().index.values
    
    # For each qid, calculate the precision of the retrieved passages. Add each precision value 
    # corresponding to each query to the empty list.
    for qid in q_ids:
        precision.append((data.loc[data['qid'] == qid, 'relevancy'] > 0).mean())
    
    # Return the average precision.
    return(np.array(precision).mean())

def ndcg_calculator(output_name, data_val_name):
    # This function takes the txt file produced by a retrieval model and the validation dataset,
    # and return the average NDCG of this model.
   
    # Read in both file as seperate dataframe 
    output = pd.read_csv(output_name, header = None, sep = '  ',
                         names = ['qid', 'assignment', 'pid', 'rank', 'score', 'model'])
    data_val = pd.read_csv(data_val_name, sep='\t')
    
    # Join them toghether so we can see the true relevancy score of the retrieved passages.
    data = pd.merge(left = output, right = data_val[['pid','qid','relevancy']], on = ['qid','pid'])
    
    # Create a empty list.
    ndcg = []
    # An array that has all the qids in it.
    q_ids = data['qid'].value_counts().index.values
    for qid in q_ids:
        # First calculate the discounted gain
        temp = data.loc[data['qid'] == qid, ['relevancy', 'rank']].sort_values('rank')
        relevancy_score = temp['relevancy'].values
        rank = temp['rank'].values
        gain = 2**(relevancy_score) - 1
        discounted_gain = gain / np.log2(rank + 1)
        
        # Then based on the true relevancy score, calculate the ideal discounted gain
        temp = temp.sort_values('relevancy', ascending = False, ignore_index = True)
        temp['rank'] = temp.index + 1
        opt_relevancy_score = temp['relevancy'].values
        opt_rank = temp["rank"].values
        opt_gain = 2**(opt_relevancy_score) - 1
        opt_discounted_gain = opt_gain / np.log2(opt_rank + 1)
        
        # If ideal discounted gain is 0, then the overall NDCG would be 0
        if opt_discounted_gain.sum() == 0:
            ndcg.append(0)
        # Else divide discounted gain by ideal discounted gain to get NDCG 
        else:
            ndcg.append(discounted_gain.sum() / opt_discounted_gain.sum())
    
    # Return the average NDCG.
    return(np.array(ndcg).mean())

#%% 3.BM25 evaluation
# So now we can see the performance of the BM25 model implemented in the previous coursework.

print('The average precision of the BM25 is',
      precision_calculator('BM25.txt', 'dataset/validation_data.tsv'))
print('The average NDCG of the BM25 is',
      ndcg_calculator('BM25.txt', 'dataset/validation_data.tsv'))




#%% 4.Data-preprocessing
def word_tokenizer(passage, dictionary):
    # This function is used to tokenize word in a passage/query.
    from nltk.tokenize import word_tokenize
    import string
    # 'data' will be taking in words of every passage in our collection.
    data = []
    for i, line in enumerate(passage):
        # Remove '\n'
        line = line.replace('\n', '')
        line = line.translate(str.maketrans("",""))
        # Remove any white space at the start or at the end
        line = line.strip()
        # Tokenize the words in each line.
        tokens = word_tokenize(line.lower())
        # Remove any punctuations and words that are not in the Fasttext n-grams
        tokens = [token for token in tokens if token not in string.punctuation and token in dictionary]        

        data.append(tokens)

    return(data)

def negative_sampler(filename, number_of_samples = 50):
    # This function use negative sampling to sample the data with 0 relevancy.
    # filename is the path of the data, number_of_samples_ is the number of negative samples to be sampled.
    
    # First, read in the data
    data_train = pd.read_csv(filename,sep='\t')[['qid','queries','passage','relevancy']].sort_values('qid', ignore_index = True)
    
    # Create a new dataframe, which will be the sample of the original dataset
    sample = pd.DataFrame(columns = data_train.columns)
    # Add all the data with positive relevancy to the sample
    sample = sample.append(data_train[data_train.relevancy == 1], ignore_index = True)
    # Create a list with qids
    qids = np.unique(data_train['qid'].values)
    # For each qid, randomly choose some rows which have 0 relevancy, 
    # with the number of sample difined in the function.
    for i, qid in enumerate(qids):
        index = data_train[(data_train.qid==qid) & (data_train.relevancy == 0)].index        
        # If the total size is smaller than the number of sample, take all the rows.
        sample_size = min(len(index), number_of_samples)
        index_sample = np.random.choice(index, size = sample_size, replace = False)
        sample = sample.append(data_train.loc[index_sample,], ignore_index = True)
        
        print(i, 'queries complete.')
    return(sample)

def transformer(data, model_name):
    # This function transform the data in text form into numerical vectors.
    # data is the text data to be transformed. model_name is the path of the pre-trained word embedding model.
    
    # Sort the data based on qid
    data = data.sort_values("qid", ignore_index = True)        
    
    #Load the pre-trained embedding model
    model = FastText.load_fasttext_format(model_name)
    
    # Extract the query and passage values
    query = data['queries'].values
    passage = data['passage'].values
    
    # group_size is the length of rows for each qid
    group_size = data['qid'].value_counts().sort_index().values
    
    # y is the label values
    y = data['relevancy'].values
    
    # Tokenize the query data and transform it to numerical vectors.
    query = word_tokenizer(query, model.wv)
    query = [model[data].mean(axis = 0) for data in query]
    
    # Tokenize the passage data and transform it to numerical vectors.
    passage = word_tokenizer(passage, model.wv)
    passage = [model[data].mean(axis = 0) for data in passage]
    
    # Concatenate passage and query vectors
    X = np.hstack((passage, query))
    
    return(X, y, group_size)

#%% 5.Load the data
'''
Finally, load the data. These data will be used through out the rest of the script.
'''
data_train = negative_sampler('dataset/train_data.tsv', number_of_samples = 200) 
data_val = pd.read_csv('dataset/validation_data.tsv', sep = '\t')
X_train, y_train, group_size = transformer(data_train, 'cc.en.300.bin')
X_val, y_val, group_size_val = transformer(data_val, 'cc.en.300.bin')

# This dataset is the top1000 candidate passages.
candidate = pd.read_csv('dataset/candidate_passages_top1000.tsv', sep = '\t',
                        names = ['qid', 'pid', 'queries', 'passage'])



#%% 6.Implement Logistic regression

def sigmoid(x):
    # Return the sigmoid value
    return  1 / (1 + np.exp(-x))
    
def compute_cost(X, y, theta):
    # Computes the logistic loss
    m = len(y)
    h = sigmoid(X @ theta)
    epsilon = 1e-5
    cost = (1/m)*(((-y).T @ np.log(h + epsilon))-((1-y).T @ np.log(1-h + epsilon)))
    return cost

def gradient_descent(X, y, params, learning_rate, iterations):
    # Using the defined learning rate to find the optimum parameters after the defined interations.
    m = len(y)
    cost_history = np.zeros((iterations,1))

    for i in range(iterations):
        start = time()
        params = params - (learning_rate/m) * (X.T @ (sigmoid(X @ params) - y)) 
        cost_history[i] = compute_cost(X, y, params)
        print('iteration', i, 'complete!', time()-start, 'seconds elapsed.')
    return (cost_history, params)

def predict(X, params):
    # Predict the value of relevancy.
    return sigmoid(X @ params)

#%% 7. Explore the effect of different learning rates on the training cost

# Defined the initial parameter
params = np.zeros(X_train.shape[1])
# Different learning rates
learning_rates = [10,1, 0.5, 0.1, 0.01]

costs = []
params_final = []
# The for-loop allows us to see the impact of different learning rates on the cost history.
for rate in learning_rates:
    cost, param = gradient_descent(X_train, y_train, params, learning_rate = rate, iterations = 500)
    costs.append(cost)
    params_final.append(param)

iterations = list(range(500))
fig, ax = plt.subplots() 
for cost, rate in zip(costs, learning_rates):
    plt.plot(iterations, cost, label = 'learning rate {}'.format(rate))
plt.xlabel('Number of iterations')
plt.ylabel('Cost')
plt.title('Cost history')
plt.legend()

# I decided to use learning rate 0.5.

#%% 8.After choosing the learning rate, validate performance and retrieve passages
params = params_final[2]

def LR(data, params, file_name, model_name):
    # This function takes in the test data, the parameter of the logistic model and the file name,
    # and ouputs a txt file of top 100 retrieved passages.
    
    # Load the pre-trained word embedding model
    model = FastText.load_fasttext_format(model_name)
    q_ids = data['qid'].value_counts().index.values
    for i, qid in enumerate(q_ids):
        pids = data.loc[data['qid'] == qid, 'pid'].values
       
        # Tokenize query and passage, transform them into numerical vectors and concanate them.
        query = data.loc[data['qid'] == qid, 'queries'].values
        passages = data.loc[data['qid'] == qid, 'passage'].values
        query = word_tokenizer(query, model.wv)
        passages = word_tokenizer(passages, model.wv)
        query = [model[x].mean(axis = 0) for x in query]
        passages = [model[x].mean(axis = 0) for x in passages]      
        X = np.hstack((passages, query))
        
        # Calculate the relevancy scores and rank them.
        scores = predict(X, params)
        index = np.argsort(scores)[::-1][:100]
        ranks = list(range(1,len(index)+1))
        
        # Output them in to a file.
        for pid, rank, score in zip(pids[index], ranks, scores[index]):
            file1 = open(file_name, 'a')
            file1.write('{}  {}  {}  {}  {}  {}\n'.format(qid,'A1',pid,rank,score,'LR'))
        print('Task {} complete. {} remaining.'.format(i, len(q_ids)-i))
    file1.close()   



LR(data_val, params, 'LR_val.txt', 'cc.en.300.bin')
LR(candidate, params, 'LR.txt', 'cc.en.300.bin')

print('The average precision of the logistic regression is',
      precision_calculator('LR_val.txt', 'dataset/validation_data.tsv'))
print('The average NDCG of the logistic regression is',
      ndcg_calculator('LR_val.txt', 'dataset/validation_data.tsv'))


#%% 9.LambdaMART algorithm tuning
'''
In order to train the LambdaMART algorithm, we need to tune the hyper-parameter of the XGBRanker()
'''

def validation(X_train, y_train, group_train,
                    X_val, y_val, group_val,
                    estimator):
    # This function evaluate the performance of the estimator on the validation dataset and returns the validation score.
    
    # Train the model on the training dataset
    estimator.fit(X_train, y_train, group_train,
                  eval_set = [(X_val, y_val)],
                  eval_group = [group_val])
    # return the score
    score = np.mean(estimator.evals_result['eval_0']['map'])
    return(score)

# First tune the max_depth and min_child_weight, we can customise the value in the list.
max_depth = [2,4,6,8,10]
min_child_weight = [2,4,6,8,10]
best_param = dict(max_depth = 0, min_child_weight = 0, score = 0)

# This for loop calculates the evaluation score on each combination of the parameter grid,
# and keeps the best score and the corresponding parameter combination.
for depth in max_depth:
    for weight in min_child_weight:
        xgb = XGBRanker(objective = 'rank:pairwise', verbosity = 2, n_estimators = 100,
                        max_depth = depth, min_child_weight = weight,
                        learning_rate = .1,
                        random_state = 2020,
                        n_jobs = 1,
                        tree_method = 'gpu_hist')
        
        score = validation(X_train, y_train, group_size,
                                X_val, y_val, group_size_val,
                                xgb)
        
        if score > best_param['score']:
            best_param['max_depth'] = depth
            best_param['min_child_weight'] = weight
            best_param['score'] = score
print(best_param)      

# After a number of rounds with different parameter grids, I get: 
# Best depth:12, best min child weight : 23


# Then we tune the gamma
gammas = [9.5,10,10.5,11]
best_param = dict(gamma = 0, score = 0)
for gamma in gammas:
    xgb = XGBRanker(objective = 'rank:pairwise', verbosity = 2, n_estimators = 100,
                        max_depth = 12, min_child_weight = 23,
                        gamma = gamma,
                        learning_rate = .1,
                        random_state = 2020,
                        n_jobs = 1,
                        tree_method = 'gpu_hist')
    score = validation(data_X, data_y, groups, estimator = xgb)
    if score > best_param['score']:
        best_param['gamma'] = gamma
        best_param['score'] = score
print(best_param)
# Best gamma: 10.5

# Next subsample and colsample_bytree
subsample = [.75,]
colsample_bytree = [.65, .7, .75, .5]
best_param = dict(subsample = 0, colsample_bytree = 0, score = 0)
for ss in subsample:
    for cs in colsample_bytree:
            xgb = XGBRanker(objective = 'rank:ndcg', verbosity = 2, n_estimators = 100,
                            max_depth = 11, min_child_weight = 20,
                            gamma = 10.5,
                            learning_rate = .1,
                            random_state = 2020,
                            n_jobs = 1,
                            tree_method = 'gpu_hist',
                            subsample = ss,
                            colsample_bytree = cs)
         
            score = validation(data_X, data_y, groups, estimator = xgb)
            if score > best_param['score']:
                best_param['subsample'] = ss
                best_param['colsample_bytree'] = cs
                best_param['score'] = score
print(best_param)
# best subsample:0.75, best colsample_bttree:0.65



# Regulation alpha
alphas = [0, .001, .01, 1, 10, 100]
best_param = dict(reg_alpha = 0, score = 0)
for alpha in alphas:
       xgb = XGBRanker(objective = 'rank:ndcg', verbosity = 2, n_estimators = 100,
                       max_depth = 11, min_child_weight = 20,
                       gamma = .45,
                       learning_rate = .1,
                       random_state = 2020,
                       n_jobs = 1,
                       tree_method = 'gpu_hist',
                       subsample = .75,
                       colsample_bytree = .65,
                       reg_alpha = alpha)
       score = crossvalidation(data_X, data_y, groups, estimator = xgb)
       if score > best_param['score']:
           best_param['reg_alpha'] = alpha
           best_param['score'] = score

print(best_param)
#best reg_alpha:0   

# Here is the final best hyper parameter
best_params = dict(max_depth = 12,
                   min_child_weight = 23,
                   gamma = 10.5,
                   subsample = .75,
                   colsample_bytree = .65,
                   reg_alpha = 0,
                   objective = 'rank:pairwise',
                   random_state = 2020,
                   n_jobs = 1,
                   tree_method ='gpu_hist')

#%% 10.After tuning, train the model, validate performance, retreive passages.

# Finally, we can train the model on the training dataset with the above best hyper parameter.
xgb = XGBRanker(learning_rate = 0.01, n_estimators = 500, **best_params)
xgb.fit(X_train, y_train, group_size)

# This function does similar to the function 'LR', which also outputs the retrieved top 100 passages to a txt file.
def XGB(data, estimator, file_name, model_name):
    model = FastText.load_fasttext_format(model_name)
    q_ids = data['qid'].value_counts().index.values
    for i, qid in enumerate(q_ids):
        
        pids = data.loc[data['qid'] == qid, 'pid'].values
        query = data.loc[data['qid'] == qid, 'queries'].values
        passages = data.loc[data['qid'] == qid, 'passage'].values
        query = word_tokenizer(query, model.wv)
        passages = word_tokenizer(passages, model.wv)
        query = [model[x].mean(axis = 0) for x in query]
        passages = [model[x].mean(axis = 0) for x in passages]
        X = np.hstack((passages, query))
        
        scores = estimator.predict(X)
        index = np.argsort(scores)[::-1][:100]
        ranks = list(range(1,len(index)+1))
        for pid, rank, score in zip(pids[index], ranks, scores[index]):
            file1 = open(file_name, 'a')
            file1.write('{}  {}  {}  {}  {}  {}\n'.format(qid,'A1',pid,rank,score,'LM'))
        print('Task {} complete. {} remaining.'.format(i, len(q_ids)-i))
    file1.close()

# Output
XGB(data_val, xgb, 'LM_val.txt','cc.en.300.bin')
XGB(candidate, xgb, 'LM.txt','cc.en.300.bin')

# Evaluation
print('The average precision of the LambdaMART is',
      precision_calculator('LM_val.txt', 'dataset/validation_data.tsv'))
print('The average NDCG of the LambdaMART is',
      ndcg_calculator('LM_val.txt', 'dataset/validation_data.tsv'))


#%% 11.Neural Network
# Finally, I implemented a neural network mode with Keras.
# This feed-forward model compresses the input length gradually, and outputs the final relevancy score.

NN = Sequential()
NN.add(Dense(300, activation = 'relu', input_dim = X_train.shape[1]))
NN.add(Dense(150, activation = 'relu'))
NN.add(Dense(75, activation = 'relu'))
NN.add(Dense(1, activation = 'sigmoid'))
NN.compile(loss = 'binary_crossentropy', optimizer = 'Adam')
NN.summary()

NN.fit(X_train, y_train, batch_size = 64, epochs = 50)
# Again, this function does the similar as previous section, that it outputs the final retrieved top 100 
# passages to a file.
def neural_net(data, estimator, file_name, model_name):
    model = FastText.load_fasttext_format(model_name)
    q_ids = data['qid'].value_counts().index.values
    for i, qid in enumerate(q_ids):
        
        pids = data.loc[data['qid'] == qid, 'pid'].values
        query = data.loc[data['qid'] == qid, 'queries'].values
        passages = data.loc[data['qid'] == qid, 'passage'].values
        query = word_tokenizer(query, model.wv)
        passages = word_tokenizer(passages, model.wv)
        query = [model[x].mean(axis = 0) for x in query]
        passages = [model[x].mean(axis = 0) for x in passages]
        X = np.hstack((passages, query))
        
        scores = estimator.predict(X)
        scores = scores.reshape(len(scores))
        index = np.argsort(scores)[::-1][:100]
        ranks = list(range(1,len(index)+1))
        for pid, rank, score in zip(pids[index], ranks, scores[index]):
            file1 = open(file_name, 'a')
            file1.write('{}  {}  {}  {}  {}  {}\n'.format(qid,'A1',pid,rank,score,'NN'))
        print('Task {} complete. {} remaining.'.format(i, len(q_ids)-i))
    file1.close()

neural_net(data_val, NN, 'NN_val.txt', 'cc.en.300.bin')
neural_net(candidate, NN, 'NN.txt', 'cc.en.300.bin')

print('The average precision of the neural network is',
      precision_calculator('NN_val.txt', 'dataset/validation_data.tsv'))
print('The average NDCG of the neural network is',
      ndcg_calculator('NN_val.txt', 'dataset/validation_data.tsv'))